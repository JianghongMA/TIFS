function [ma,mi,exp,acc]=TIFS(X_train,Y_train,X_test,Y_test,s,k,tau,delta)

%s: number of topics
%k: kNN
%X \in [0,1]
%Y \in {0,1}


% [n,d]=size(X);
% [n,k]=size(Y);
% 
% ma=max(X);
% mi=min(X);
% 
% X=(X-repmat(mi,n,1))./(repmat(ma-mi,n,1));
% 
% max(max(X))
% min(min(X))
% 
% Y(Y==-1)=0;
% 
% %%% data separation
% r = 0.2;%ratio of test data
% Label = Y;
% % Label(Label==0)=-1;
% Y = double(Label);
% X = double(X);
% [n_total, n_feat] = size(X);
% n_test = round(r*n_total);
% n_train = n_total - n_test;
% 
% nCross = 5; %here we use 5-cross-validation
% rand_sq = randperm(n_total);
% for i=1:nCross-1
%     test_sq{i} = rand_sq((i-1)*n_test+1:i*n_test);
%     temp = 1:n_total;
%     temp(test_sq{i}) = [];
%     train_sq{i} = temp;
% end
%  i = nCross;
%  test_sq{i} = rand_sq((i-1)*n_test+1:end);
%  temp = 1:n_total;
%  temp(test_sq{i}) = [];
%  train_sq{i} = temp;
%  
% X_train=X(train_sq{1},:);
% X_test=X(test_sq{1},:);
% 
% Y_train=Y(train_sq{1},:);
% Y_test=Y(test_sq{1},:);

 %%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%


iter1=300;

addpath('evaluation');


%%%%%%%%%% multi-topic combination and intra-topic distribution
G=affinity(Y_train);
IDX = kmeans(X_train, s);

A=[];
B=[];

for j=1:s
    [ix,~]=find(IDX==j);
    if length(ix)~=1
    A=[A;mean(X_train(ix,:))];
    B=[B;mean(Y_train(ix,:))]; 
    else
    A=[A;X_train(ix,:)];
    B=[B;Y_train(ix,:)];
    end
end
       
        
        U1=ones(size(X_train,1),s); 
        U2=ones(size(X_test,1),s); 
        H=ones(s,s);
        
        for m=1:iter1           
U1=U1.*((1+tau)*X_train*(A)'+(1+tau)*Y_train*(B)')./(U1*(A)*(A)'+U1*(B)*(B)'+tau*(ones(s,size(X_train,1))*(eye(size(X_train,1)).*(X_train*X_train'+Y_train*Y_train')))'+tau*((eye(s).*(A*A'+B*B'))*ones(s,size(X_train,1)))'+1e-6);
B=B.*((1+tau)*(U1)'*Y_train+H'*B*G)./((U1)'*(U1)*B+tau*(U1'*ones(size(Y_train,1),size(Y_train,2))).*B+H'*B*B'*H*B+delta);
A=A.*((1+tau)*(U1)'*X_train)./((U1)'*(U1)*A+tau*(U1'*ones(size(X_train,1),1)*ones(1,size(X_train,2))).*A+delta);
H=H.*(B*G'*B')./(B*B'*H*B*B'+1e-6); 
        end
        

        for m=1:iter1
            U2=U2.*((1+tau)*X_test*(A)')./(U2*(A)*(A)'+tau*(ones(s,size(X_test,1))*(eye(size(X_test,1)).*(X_test*X_test')))'+tau*((eye(s).*(A*A'))*ones(s,size(X_test,1)))'+1e-6);
        end


%%%%%%%%%% inter-topic correlation
iter2=300;

Q=ones(s,s)*1/s;
for j=1:s
    Q(j,j)=0;
end

 Q1=A*A'+B*B';
 Q2=U1'*U1;

a=0;
for i=1:s
    for j=1:s
        a=a+max(reshape(Q1(:,i)*Q2(j,:),s*s,1))^2;
    end
end

L2=s*sqrt(a)+eps;

D1=(A*X_train'+B*Y_train')*U1;

for i=1:iter2
    dQ=Q1*Q*Q2-D1;
    Q3=((Q-(1/L2)*dQ)+(Q-(1/L2)*dQ)')/2;
    
    b=(eye(s)/s+(2-s)/(2*s^2*(s-1))*ones(s,s))*(ones(s,1)-Q3*ones(s,1)+trace(Q3)*ones(s,1)/s);
    c=-1/s*(trace(Q3)+2*b'*ones(s,1));
    
    Q=Q3+c*eye(s)+ones(s,1)*b'+b*ones(1,s);
    Q4=(Q>=0);
    Q=Q4.*Q; 
end


%%%%%%%%%% prediction

 U1=U1*(0.5*eye(s)+0.5*Q);
 U2=U2*(0.5*eye(s)+0.5*Q);
%  
T=diag(U1*U1')*ones(1,size(U2,1))-2*U1*U2'+ones(size(U1,1),1)*(diag(U2*U2'))';


ab1=[];ab2=[];
for i=1:size(U2,1)
    [ia,ib]=sort(T(:,i),'ascend');
    ab1=[ab1,ia];
    ab2=[ab2,ib];
end


Y_pre=[];
for i=1:size(U2,1)   
Y_pre=[Y_pre;mean(Y_train(ab2(1:k,i),:))];
end

Y_pre=Y_pre+U2*B;


 Y_pre(find(Y_pre<0.5))=-1;
 Y_pre(find(Y_pre>=0.5))=1;


Y_test(Y_test==0)=-1;

[~, ma, mi] = compute_measures(Y_test, Y_pre);

[~, exp,~] = compute_measures(Y_test', Y_pre');

Y_pre(find(Y_pre==-1))=0;
Y_test(find(Y_test==-1))=0;
[~,acc]=PerformanceMeasure(Y_test, Y_pre);



