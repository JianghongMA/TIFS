function A=affinity(Y)
Y(find(Y==-1))=0;
[n,c]=size(Y);
A=[];
for i=1:c
    for j=1:c
        if (Y(:,i)'*Y(:,i)==0)||(Y(:,j)'*Y(:,j)==0)
            A(i,j)=0;
        else
        A(i,j)=Y(:,i)'*Y(:,j)/(sqrt(Y(:,i)'*Y(:,i)).*sqrt(Y(:,j)'*Y(:,j)));
        end
    end
end

for i=1:c
     A(i,i)=0;
end
    

