function [F1, prec, rec, spe] = computeF1_3(TP, FP, TN, FN)

if TP+FP == 0
    prec = 0;
else
    prec = TP/(TP+FP);
end
if TP + FN == 0
    rec = 0.5;
else
    rec = TP/(TP+FN);
end
if TN + FP == 0
    spe = 0.5;
else
    spe = TN/(TN+FP);
end
if prec+rec == 0
    F1 = 0;
else
    F1 = 2*prec*rec / (prec+rec);
end
    